var request = require('request');

module.exports.eventHubConsumer = function (context, eventHubData) {
    var event = {};
    event.func = process.env.appName;
    if (Array.isArray(eventHubData)) eventHubData = eventHubData[0];
    context.log(event.func + ' called.');
    var logs = eventHubData.records;
    if (!logs || !Array.isArray(logs)) {
        return context.done();
    }

    event.invokationId = context.invokationId;
    event.logs = [];
    event.subscriptionId = getSubscriptionId(logs);
    event.url = process.env.espChannelURL;
    logs.forEach(function (log) {
        event.logs.push(buildEvent(log));
    });
    sendEvent(context, event);
};

function buildEvent(log) {
    return {"eventId": log.id, "log": JSON.stringify(log)};
}

function sendEvent(context, event) {
    context.log('Sending to url: ' + event.url + ' for subscription: ' + event.subscriptionId);
    request.post(event.url, {
        json: {
            "function" : event.func,
            "invokationId" : event.invokationId,
            "subscriptionId": event.subscriptionId,
            "logs": event.logs
        }
    }, function (error, response) {
        if (error) {
            context.log('Error posting the message');
            context.done(error);
        }
        else {
            context.log('Successfully posted the message');
            context.log("repsonse: ", JSON.stringify(response));
            context.done();
        }
    });
}

function getSubscriptionId(logs) {
    var ret = '';
    if (logs && logs[0] && logs[0].resourceId) {
        var r = logs[0].resourceId.toLowerCase().match(/\/subscriptions\/([^\/]+)\//);
        if (r) {
            ret = r[1];
        }
    }
    return ret;
}